# 常用

Ctrl+N 创建新得page
Ctrl+Shift+N 打开一个新的notion窗口
Ctrl+U 转到父页面
Ctrl+P 打开搜索或跳至最近浏览得页面
Ctrl+[ 返回上一页
Ctrl+] 进入页面
Ctrl+Shift+L 黑夜模式
Ctrl+\ 打开/关闭侧边栏

# markdown

** 加粗文本
* 斜体
` 内联代码
~ 删除线
[] 待办清单
1. 有序表格
# 一级标题
## 二级标题
### 三级标题
> 折叠列表
>" 引用

# 内容

Ctrl+Shift+123 标题123
Ctrl+Shift+4 待办
Ctrl+Shift+5 无序列表
Ctrl+Shift+6 有序列表
Ctrl+Shift+7 折叠列表
Ctrl+Shift+8 引用
Ctrl+Shift+9 页面
Ctrl+B 粗体
Ctrl+i 斜体
Ctrl+u 下划线
Ctrl+Shift+s 删除线
Ctrl+K 链接
Ctrl+E 内联代码
Ctrl+E 内联代码
Ctrl+E 内联代码
Ctrl+E 内联代码