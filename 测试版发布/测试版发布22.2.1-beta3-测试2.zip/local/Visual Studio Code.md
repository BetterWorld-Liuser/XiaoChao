# Code

Ctrl+/ 切换注释
Ctrl+\ 分割窗口
Ctrl+` 切换终端
Ctrl+Shift+P 显示面板
Ctrl+K..S 查找快捷键
