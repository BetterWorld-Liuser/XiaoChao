# OneNote

Ctrl+Alt+1 标题一
通天塔 快速打开 onenote:https://d.docs.live.net/02baf6f87edc7f92/Apps/OneNote/OneNote%20笔记本/兴趣爱好/通天塔/通天塔.one#section-id={3499556A-F674-4A3F-9C71-E26778A7D494}&end
面试笔记 快速打开 onenote:https://d.docs.live.net/02baf6f87edc7f92/桌面/复试/笔记/复试笔记/面试.one#section-id={8E099726-52F0-42EB-8955-6015A15EFF26}&end
集成电路调剂 快速打开 onenote:https://d.docs.live.net/02baf6f87edc7f92/桌面/复试/笔记/复试笔记/调剂.one#集成电路学院&section-id={A41159DE-06FE-4794-9F49-2C992A3A0522}&page-id={8BC1F2D5-50AD-4BFA-925A-5218577A544D}&end
快捷键助手 快速打开 onenote:https://d.docs.live.net/02baf6f87edc7f92/Apps/OneNote/OneNote%20笔记本/兴趣爱好/快捷键助手/