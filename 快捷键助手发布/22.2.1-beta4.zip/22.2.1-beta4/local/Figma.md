# Figma

A/F 新建画布
K 按比例缩放
V 鼠标
C 评论模式
Alt 复制组件
Shift+1 画布缩放到合适位置
Shift+2 组件缩放到合适位置
Shift+R 显示/隐藏标尺
Ctrl+G 编组
Ctrl+/ 搜索菜单/插件..
Ctrl+SHift+G 取消编组
Ctrl+Alt 替换组件
Ctrl+Alt+S 增加历史版本
Ctrl+Alt+G 元素增加Frame
Ctrl+Shift+4 显示网格
Alt+1 显示layer
Alt+2 显示Asset

紫色 组件
