# Edge

Ctrl+Shift+T 撤回关闭窗口
Ctrl+W 关闭窗口
