# Excel
Ctrl+1 设置格式
Ctrl+E 拆分/合并数据
Ctrl+T 创建超级表
Ctrl+G 定位
Ctrl+F 查找
Ctrl+/ 找出不同
Ctrl+; 当前日期
Ctrl+Shift+; 当前时间


Alt+= 求和
Alt+F 生成图表