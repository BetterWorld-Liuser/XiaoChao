# 常用

Ctrl+Shift+G 焦点放在当前分区上
Shift+F10 打开上下文菜单
Ctrl+N 添加新页
Ctrl+O 打开笔记本
Ctrl+G 切换笔记本
Ctrl+T 创建新分区
Ctrl+Alt+N 创建新页面
Ctrl+Alt+Shift+N 创建子页
F11 启/禁用整页视图
Ctrl+Alt+G 聚焦页面选项卡
Ctrl+Alt+M 移动/复制页
Ctrl+Shift+T 跳转到页面标题
Ctrl+E 搜索
